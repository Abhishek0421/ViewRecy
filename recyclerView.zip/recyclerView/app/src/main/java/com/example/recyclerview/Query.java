package com.example.recyclerview;

import androidx.appcompat.app.AppCompatActivity;

public class Query extends AppCompatActivity {

}
