package com.example.recyclerview;



import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class RecyclerChatAdapter extends RecyclerView.Adapter<RecyclerChatAdapter.ViewHolder> {

    Context context;
    ArrayList<chatModel> arrchat;
    RecyclerChatAdapter(Context context , ArrayList<chatModel> arrchat){
        this.context = context;
        this.arrchat = arrchat;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.chat_layout,parent,false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.chat.setText(arrchat.get(position).message);
    }

    @Override
    public int getItemCount() {
        return arrchat.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView chat;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            chat = itemView.findViewById(R.id.chats);
        }
    }
}
