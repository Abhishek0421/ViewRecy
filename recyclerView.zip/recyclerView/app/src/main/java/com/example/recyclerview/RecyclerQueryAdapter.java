package com.example.recyclerview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class RecyclerQueryAdapter extends RecyclerView.Adapter<RecyclerQueryAdapter.ViewHolder> {
    Context context;
    ArrayList<QueryModel> arrQuery;
    @NonNull
    @Override
    public RecyclerQueryAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.query_layout,parent,false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerQueryAdapter.ViewHolder holder, int position) {
        holder.query.setText(arrQuery.get(position).str);
    }

    @Override
    public int getItemCount() {
        return arrQuery.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView query;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            query = itemView.findViewById(R.id.right_chat_textview);
        }
    }
}
