package com.example.recyclerview;

public class QueryModel {
    String str;

    public QueryModel(String str) {
        this.str = str;
    }
}
