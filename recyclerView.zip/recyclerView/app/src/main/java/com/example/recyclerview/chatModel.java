package com.example.recyclerview;

import androidx.appcompat.app.AppCompatActivity;

public class chatModel {
    String message;

    public chatModel(String message) {
        this.message= message;
    }
}
