package com.example.recyclerview;

import android.net.Uri;

import androidx.appcompat.app.AppCompatActivity;

import java.net.URI;

public class chatModel {
    String message;
    Uri uri;


    public chatModel(String message) {
        this.message = message;

    }

    public  chatModel(String message,Uri uri){
        this.uri = uri;
        this.message = message;
    }
}
