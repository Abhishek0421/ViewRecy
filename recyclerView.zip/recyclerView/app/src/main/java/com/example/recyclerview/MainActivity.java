package com.example.recyclerview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ArrayList<chatModel> arrChat = new ArrayList<>();
    EditText chatMessage ;
    ImageButton sendButton;
    RecyclerView recyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sendButton = findViewById(R.id.message_send_btn);

        chatMessage = findViewById(R.id.chat_message_input);

        recyclerView = findViewById(R.id.chatView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));


        RecyclerChatAdapter recyclerChatAdapter = new RecyclerChatAdapter(this,arrChat);
        LinearLayoutManager manager = new LinearLayoutManager(this);

        recyclerView.setAdapter(recyclerChatAdapter);

        sendButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                String message = chatMessage.getText().toString().trim();
                if(message.isEmpty()){
                    return;
                }
                addChats(message);
                chatMessage.setText("");
                recyclerChatAdapter.notifyItemInserted(arrChat.size()-1);
                recyclerView.smoothScrollToPosition(arrChat.size()-1);
            }
        });

    }
    void addChats(String message){
        arrChat.add(new chatModel(message));
    }
}

