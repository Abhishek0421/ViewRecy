package com.example.recyclerview;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import java.net.URI;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ArrayList<chatModel> arrChat = new ArrayList<>();
    EditText chatMessage ;
    ImageButton sendButton;
    ImageButton addButton;
    AppCompatButton Querybtn;
    RecyclerView recyclerView;
    RecyclerChatAdapter recyclerChatAdapter;

    String imageDes;
    private final int Gallary_Eccess_code = 1000;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Querybtn = findViewById(R.id.Query_button);
        Querybtn.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, Query1.class);
            startActivity(intent);
        });
        addButton = findViewById(R.id.add_btn);

        addButton.setOnClickListener(view -> {
            Intent iGallary = new Intent(Intent.ACTION_PICK);
            imageDes = chatMessage.getText().toString();
            iGallary.setData(MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            startActivityForResult(iGallary,Gallary_Eccess_code);
        });
        sendButton = findViewById(R.id.message_send_btn);

        chatMessage = findViewById(R.id.chat_message_input);

        recyclerView = findViewById(R.id.chatView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));


        recyclerChatAdapter = new RecyclerChatAdapter(this,arrChat);
        LinearLayoutManager manager = new LinearLayoutManager(this);

        recyclerView.setAdapter(recyclerChatAdapter);

        sendButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                String message = chatMessage.getText().toString().trim();
                if(message.isEmpty()){
                    return;
                }
                addChats(message);
                chatMessage.setText("");
                recyclerChatAdapter.notifyItemInserted(arrChat.size()-1);
                recyclerView.smoothScrollToPosition(arrChat.size()-1);
            }
        });


    }
    void addChats(String message){
        Uri u = null;
        arrChat.add(new chatModel(message, null));
    }
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode == 1000){
            assert data != null;
            Uri uri = data.getData();
            arrChat.add(new chatModel("",uri));
            recyclerChatAdapter.notifyItemInserted(arrChat.size()-1);
            recyclerView.smoothScrollToPosition(arrChat.size()-1);
        }
    }

}

